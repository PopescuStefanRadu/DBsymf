<?php

/* default/addthread.html.twig */
class __TwigTemplate_2d7a03c58732d1d3487d1bf9ef4e2d087441745eeae19d003de6b22e47ac0861 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/addthread.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_64560c513333cf131a847bdb07c762f4dc3393bcefa583bdf132bc996a872b0b = $this->env->getExtension("native_profiler");
        $__internal_64560c513333cf131a847bdb07c762f4dc3393bcefa583bdf132bc996a872b0b->enter($__internal_64560c513333cf131a847bdb07c762f4dc3393bcefa583bdf132bc996a872b0b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/addthread.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_64560c513333cf131a847bdb07c762f4dc3393bcefa583bdf132bc996a872b0b->leave($__internal_64560c513333cf131a847bdb07c762f4dc3393bcefa583bdf132bc996a872b0b_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_ca85a8931622d4fefc2d3feb7ba3830019cf3f3194f02d8c91f2608c1263d410 = $this->env->getExtension("native_profiler");
        $__internal_ca85a8931622d4fefc2d3feb7ba3830019cf3f3194f02d8c91f2608c1263d410->enter($__internal_ca85a8931622d4fefc2d3feb7ba3830019cf3f3194f02d8c91f2608c1263d410_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/jquery-ui.css"), "html", null, true);
        echo "\"/>
";
        
        $__internal_ca85a8931622d4fefc2d3feb7ba3830019cf3f3194f02d8c91f2608c1263d410->leave($__internal_ca85a8931622d4fefc2d3feb7ba3830019cf3f3194f02d8c91f2608c1263d410_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_fd070fc4e32b92564beb82039e145e2d178a462784b993df1fe9801c79c5b674 = $this->env->getExtension("native_profiler");
        $__internal_fd070fc4e32b92564beb82039e145e2d178a462784b993df1fe9801c79c5b674->enter($__internal_fd070fc4e32b92564beb82039e145e2d178a462784b993df1fe9801c79c5b674_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container\">
    ";
        // line 11
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start');
        echo "
    ";
        // line 12
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
    ";
        // line 13
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </div>
";
        
        $__internal_fd070fc4e32b92564beb82039e145e2d178a462784b993df1fe9801c79c5b674->leave($__internal_fd070fc4e32b92564beb82039e145e2d178a462784b993df1fe9801c79c5b674_prof);

    }

    // line 17
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5a1ff8c095bdda15e42e2dd889dea5b3f857f5d6bb99535db47bfe42b38dac63 = $this->env->getExtension("native_profiler");
        $__internal_5a1ff8c095bdda15e42e2dd889dea5b3f857f5d6bb99535db47bfe42b38dac63->enter($__internal_5a1ff8c095bdda15e42e2dd889dea5b3f857f5d6bb99535db47bfe42b38dac63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 18
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/js/jquery-ui.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl((isset($context["js"]) ? $context["js"] : $this->getContext($context, "js"))), "html", null, true);
        echo "\"></script>
";
        
        $__internal_5a1ff8c095bdda15e42e2dd889dea5b3f857f5d6bb99535db47bfe42b38dac63->leave($__internal_5a1ff8c095bdda15e42e2dd889dea5b3f857f5d6bb99535db47bfe42b38dac63_prof);

    }

    public function getTemplateName()
    {
        return "default/addthread.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  101 => 20,  97 => 19,  92 => 18,  86 => 17,  76 => 13,  72 => 12,  68 => 11,  62 => 9,  56 => 8,  47 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block stylesheets %}*/
/*     {{ parent() }}*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/jquery-ui.css')}}"/>*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {{ parent() }}*/
/*     <div class="container">*/
/*     {{ form_start(form) }}*/
/*     {{ form_widget(form) }}*/
/*     {{ form_end(form) }}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {{ parent() }}*/
/*     <script src="{{asset('assets/public/js/jquery-ui.js')}}"></script>*/
/*     <script src="{{asset(js)}}"></script>*/
/* {% endblock %}*/
