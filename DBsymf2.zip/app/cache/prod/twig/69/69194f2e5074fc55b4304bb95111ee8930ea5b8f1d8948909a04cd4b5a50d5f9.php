<?php

/* base.html.twig */
class __TwigTemplate_b0da5f2a9abb58e2d9f3202d6a14df5cac6af287df48bfb8c8702a5ca4f1fd03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9bb82f7c6581bfa6ef8eda122e3787f9542b723d4e9014e977999bb606c4587c = $this->env->getExtension("native_profiler");
        $__internal_9bb82f7c6581bfa6ef8eda122e3787f9542b723d4e9014e977999bb606c4587c->enter($__internal_9bb82f7c6581bfa6ef8eda122e3787f9542b723d4e9014e977999bb606c4587c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <meta name=\"description\" content=\"Despre carte si alte arte\">
        <meta name=\"author\" content=\"Iulia Albota\">
        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/img/mysql.png"), "html", null, true);
        echo "\" />

    </head>
    <body>
        ";
        // line 17
        $this->displayBlock('body', $context, $blocks);
        // line 22
        echo "

        ";
        // line 24
        $this->displayBlock('javascripts', $context, $blocks);
        // line 28
        echo "    </body>
</html>
";
        
        $__internal_9bb82f7c6581bfa6ef8eda122e3787f9542b723d4e9014e977999bb606c4587c->leave($__internal_9bb82f7c6581bfa6ef8eda122e3787f9542b723d4e9014e977999bb606c4587c_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_c44c77e1164d13151471df055d296c177df10c14e5951f282c40c954be7231d3 = $this->env->getExtension("native_profiler");
        $__internal_c44c77e1164d13151471df055d296c177df10c14e5951f282c40c954be7231d3->enter($__internal_c44c77e1164d13151471df055d296c177df10c14e5951f282c40c954be7231d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "DBProject";
        
        $__internal_c44c77e1164d13151471df055d296c177df10c14e5951f282c40c954be7231d3->leave($__internal_c44c77e1164d13151471df055d296c177df10c14e5951f282c40c954be7231d3_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_35aa60d3cdc347580917d65a2d7fdf31703b359b114aa0e22308d1500045a8f9 = $this->env->getExtension("native_profiler");
        $__internal_35aa60d3cdc347580917d65a2d7fdf31703b359b114aa0e22308d1500045a8f9->enter($__internal_35aa60d3cdc347580917d65a2d7fdf31703b359b114aa0e22308d1500045a8f9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "            <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/bootstrap_1.css"), "html", null, true);
        echo "\"/>
            <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/base.css"), "html", null, true);
        echo "\"/>
        ";
        
        $__internal_35aa60d3cdc347580917d65a2d7fdf31703b359b114aa0e22308d1500045a8f9->leave($__internal_35aa60d3cdc347580917d65a2d7fdf31703b359b114aa0e22308d1500045a8f9_prof);

    }

    // line 17
    public function block_body($context, array $blocks = array())
    {
        $__internal_d87f95990d9eebb84ff72654c5196fe51be5e3e6702310ce02bebe8802d87606 = $this->env->getExtension("native_profiler");
        $__internal_d87f95990d9eebb84ff72654c5196fe51be5e3e6702310ce02bebe8802d87606->enter($__internal_d87f95990d9eebb84ff72654c5196fe51be5e3e6702310ce02bebe8802d87606_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 18
        echo "            <div class=\"container-fluid\">
            </div>
            ";
        // line 20
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppBundle:Default:navigation"));
        echo "
        ";
        
        $__internal_d87f95990d9eebb84ff72654c5196fe51be5e3e6702310ce02bebe8802d87606->leave($__internal_d87f95990d9eebb84ff72654c5196fe51be5e3e6702310ce02bebe8802d87606_prof);

    }

    // line 24
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_5381b0ce27cab025e0f1954752e0cfce220326e633b81322439ca2a66ca933e9 = $this->env->getExtension("native_profiler");
        $__internal_5381b0ce27cab025e0f1954752e0cfce220326e633b81322439ca2a66ca933e9->enter($__internal_5381b0ce27cab025e0f1954752e0cfce220326e633b81322439ca2a66ca933e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 25
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/jquery/dist/jquery.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/bootstrap/dist/js/bootstrap.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_5381b0ce27cab025e0f1954752e0cfce220326e633b81322439ca2a66ca933e9->leave($__internal_5381b0ce27cab025e0f1954752e0cfce220326e633b81322439ca2a66ca933e9_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 26,  124 => 25,  118 => 24,  109 => 20,  105 => 18,  99 => 17,  90 => 10,  85 => 9,  79 => 8,  67 => 5,  58 => 28,  56 => 24,  52 => 22,  50 => 17,  43 => 13,  40 => 12,  38 => 8,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}DBProject{% endblock %}</title>*/
/*         <meta name="description" content="Despre carte si alte arte">*/
/*         <meta name="author" content="Iulia Albota">*/
/*         {% block stylesheets %}*/
/*             <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/bootstrap_1.css')}}"/>*/
/*             <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/base.css')}}"/>*/
/*         {% endblock %}*/
/* */
/*         <link rel="icon" type="image/png" href="{{ asset('assets/public/img/mysql.png') }}" />*/
/* */
/*     </head>*/
/*     <body>*/
/*         {% block body %}*/
/*             <div class="container-fluid">*/
/*             </div>*/
/*             {{ render(controller('AppBundle:Default:navigation')) }}*/
/*         {% endblock %}*/
/* */
/* */
/*         {% block javascripts %}*/
/*             <script src="{{ asset('assets/vendor/jquery/dist/jquery.js') }}"></script>*/
/*             <script src="{{ asset('assets/vendor/bootstrap/dist/js/bootstrap.js') }}"></script>*/
/*         {% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
