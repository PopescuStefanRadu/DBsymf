<?php

/* default/post.html.twig */
class __TwigTemplate_a4f00dfa97b1b5923bab515c2bc65f528323bd940494e3e0fd680b00611dca0c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/post.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f38e7ff9e8a8d821f3042a95b2d6492e5df91bd1a8fc3a6ad999559e4276346d = $this->env->getExtension("native_profiler");
        $__internal_f38e7ff9e8a8d821f3042a95b2d6492e5df91bd1a8fc3a6ad999559e4276346d->enter($__internal_f38e7ff9e8a8d821f3042a95b2d6492e5df91bd1a8fc3a6ad999559e4276346d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/post.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f38e7ff9e8a8d821f3042a95b2d6492e5df91bd1a8fc3a6ad999559e4276346d->leave($__internal_f38e7ff9e8a8d821f3042a95b2d6492e5df91bd1a8fc3a6ad999559e4276346d_prof);

    }

    // line 2
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_2cdfadc703959599e58e85f59bc4d571d4023f59227fb5ae09c72642283765d9 = $this->env->getExtension("native_profiler");
        $__internal_2cdfadc703959599e58e85f59bc4d571d4023f59227fb5ae09c72642283765d9->enter($__internal_2cdfadc703959599e58e85f59bc4d571d4023f59227fb5ae09c72642283765d9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 3
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/blog.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/css/blueimp-gallery.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/css/bootstrap-image-gallery.css"), "html", null, true);
        echo "\"/>
";
        
        $__internal_2cdfadc703959599e58e85f59bc4d571d4023f59227fb5ae09c72642283765d9->leave($__internal_2cdfadc703959599e58e85f59bc4d571d4023f59227fb5ae09c72642283765d9_prof);

    }

    // line 9
    public function block_body($context, array $blocks = array())
    {
        $__internal_275ef49abb1379eee2f53def37b8ef30b1270342cfce0b1506f1b8801ba7ddb6 = $this->env->getExtension("native_profiler");
        $__internal_275ef49abb1379eee2f53def37b8ef30b1270342cfce0b1506f1b8801ba7ddb6->enter($__internal_275ef49abb1379eee2f53def37b8ef30b1270342cfce0b1506f1b8801ba7ddb6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 10
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 11
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 12
            echo "        ";
            if ($this->env->getExtension('app_extension')->theinstanceof($context["post"], "AppBundle\\Entity\\Threads")) {
                // line 13
                echo "            <div class=\"container main\">
                <div class=\"row\">
                    <div class=\"col-sm-9\">
                        <div class=\"blog-main\">
                            <div class=\"blog-post\">
                                <h2 class=\"blog-post-title\">
                                    <a href=\"";
                // line 19
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("post_title", array("pid" => $this->getAttribute($context["post"], "x", array()), "ptitle" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($context["post"], "title", array())))), "html", null, true);
                echo "\">
                                        ";
                // line 20
                echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
                echo "</a>
                                </h2>
                                <p class=\"blog-post-meta\">
                                    ";
                // line 23
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "dateTime", array()), "d/m/Y H:i"), "html", null, true);
                echo " by <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("user_profile_name", array("profileid" => $this->getAttribute($this->getAttribute($context["post"], "user", array()), "id", array()), "profilename" => $this->getAttribute($this->getAttribute($context["post"], "user", array()), "username", array()))), "html", null, true);
                echo "\">
                                        ";
                // line 24
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["post"], "user", array()), "username", array()), "html", null, true);
                echo "
                                    </a>
                                    <br>
                                    ";
                // line 27
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["post"], "postTagsList", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["posttag"]) {
                    // line 28
                    echo "                                        <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("tags_name", array("tagid" => $this->getAttribute($this->getAttribute($context["posttag"], "tag", array()), "x", array()), "tagname" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($this->getAttribute($context["posttag"], "tag", array()), "title", array())))), "html", null, true);
                    echo "\"><span class=\"tag\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["posttag"], "tag", array()), "title", array()), "html", null, true);
                    echo "</span></a>
                                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['posttag'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 30
                echo "                                </p>
                                ";
                // line 31
                echo $this->env->getExtension('parsedown')->parsedown($this->getAttribute($context["post"], "content", array()));
                echo "
                            </div>
                        </div>
                    </div>
                    <div class=\"col-sm-3\">
                        <div class=\"blog-sidebar\">
                            ";
                // line 37
                if ($this->env->getExtension('security')->isGranted("ROLE_AUTHOR")) {
                    // line 38
                    echo "                                <div class=\"sidebar-module sidebar-module-inset\">
                                    <a class=\"btn btn-default btn-block\" href=\"";
                    // line 39
                    echo $this->env->getExtension('routing')->getPath("add_thread");
                    echo "\">Posteaza un thread</a>
                                    <a class=\"btn btn-default btn-block\" href=\"\">Posteaza o galerie</a>
                                </div>
                            ";
                }
                // line 43
                echo "                            <div class=\"sidebar-module sidebar-module-inset\">
                                <h4>Siteuri asociate</h4>
                                <ol class=\"list-unstyled\">
                                    <li><a href=\"https://www.facebook.com/iulia.drache\">Facebook Iulia Albota</a></li>
                                    <li><a href=\"https://www.facebook.com/Sec%C8%9Bia-14-grup-literar-996081047120103/\">Facebook Sectia 14</a></li>
                                </ol>
                            </div>
                            <div class=\"sidebar-module sidebar-module-inset\">
                                <h4>Tags</h4>
                                ";
                // line 52
                echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppBundle:Default:showTagList"));
                echo "
                            </div>
                        </div>    
                    </div>
                </div>
            ";
            } elseif ($this->env->getExtension('app_extension')->theinstanceof(            // line 57
$context["post"], "AppBundle\\Entity\\Imagegalleries")) {
                echo "    
                Gallery
            ";
            }
            // line 60
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "    ";
        
        $__internal_275ef49abb1379eee2f53def37b8ef30b1270342cfce0b1506f1b8801ba7ddb6->leave($__internal_275ef49abb1379eee2f53def37b8ef30b1270342cfce0b1506f1b8801ba7ddb6_prof);

    }

    // line 63
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_4028ddfdfa07a50de42b0942eeccc20cc535f4031cd731fa7d1965b03608994d = $this->env->getExtension("native_profiler");
        $__internal_4028ddfdfa07a50de42b0942eeccc20cc535f4031cd731fa7d1965b03608994d->enter($__internal_4028ddfdfa07a50de42b0942eeccc20cc535f4031cd731fa7d1965b03608994d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 64
        echo "        ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
        <script src=\"";
        // line 65
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/js/blueimp-gallery.js"), "html", null, true);
        echo "\"></script>
        <script src=\"";
        // line 66
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/js/bootstrap-image-gallery.js"), "html", null, true);
        echo "\"></script>
    ";
        
        $__internal_4028ddfdfa07a50de42b0942eeccc20cc535f4031cd731fa7d1965b03608994d->leave($__internal_4028ddfdfa07a50de42b0942eeccc20cc535f4031cd731fa7d1965b03608994d_prof);

    }

    public function getTemplateName()
    {
        return "default/post.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  204 => 66,  200 => 65,  195 => 64,  189 => 63,  182 => 61,  176 => 60,  170 => 57,  162 => 52,  151 => 43,  144 => 39,  141 => 38,  139 => 37,  130 => 31,  127 => 30,  116 => 28,  112 => 27,  106 => 24,  100 => 23,  94 => 20,  90 => 19,  82 => 13,  79 => 12,  75 => 11,  70 => 10,  64 => 9,  55 => 6,  51 => 5,  47 => 4,  42 => 3,  36 => 2,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* {% block stylesheets %}*/
/*     {{ parent() }}*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/blog.css')}}"/>*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/vendor/blueimp/css/blueimp-gallery.css') }}"/>*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/vendor/blueimp/css/bootstrap-image-gallery.css') }}"/>*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {{ parent() }}*/
/*     {% for post in posts %}*/
/*         {% if post is aninstanceof('AppBundle\\Entity\\Threads') %}*/
/*             <div class="container main">*/
/*                 <div class="row">*/
/*                     <div class="col-sm-9">*/
/*                         <div class="blog-main">*/
/*                             <div class="blog-post">*/
/*                                 <h2 class="blog-post-title">*/
/*                                     <a href="{{path('post_title',{'pid':post.x,'ptitle':post.title|makeLink})}}">*/
/*                                         {{post.title}}</a>*/
/*                                 </h2>*/
/*                                 <p class="blog-post-meta">*/
/*                                     {{post.dateTime|date('d/m/Y H:i')}} by <a href="{{path('user_profile_name',{'profileid':post.user.id,'profilename':post.user.username})}}">*/
/*                                         {{post.user.username}}*/
/*                                     </a>*/
/*                                     <br>*/
/*                                     {% for posttag in post.postTagsList %}*/
/*                                         <a href="{{path('tags_name',{'tagid':posttag.tag.x,'tagname':posttag.tag.title|makeLink})}}"><span class="tag">{{ posttag.tag.title }}</span></a>*/
/*                                         {% endfor %}*/
/*                                 </p>*/
/*                                 {{post.content|parsedown}}*/
/*                             </div>*/
/*                         </div>*/
/*                     </div>*/
/*                     <div class="col-sm-3">*/
/*                         <div class="blog-sidebar">*/
/*                             {% if is_granted('ROLE_AUTHOR')%}*/
/*                                 <div class="sidebar-module sidebar-module-inset">*/
/*                                     <a class="btn btn-default btn-block" href="{{path('add_thread')}}">Posteaza un thread</a>*/
/*                                     <a class="btn btn-default btn-block" href="">Posteaza o galerie</a>*/
/*                                 </div>*/
/*                             {% endif %}*/
/*                             <div class="sidebar-module sidebar-module-inset">*/
/*                                 <h4>Siteuri asociate</h4>*/
/*                                 <ol class="list-unstyled">*/
/*                                     <li><a href="https://www.facebook.com/iulia.drache">Facebook Iulia Albota</a></li>*/
/*                                     <li><a href="https://www.facebook.com/Sec%C8%9Bia-14-grup-literar-996081047120103/">Facebook Sectia 14</a></li>*/
/*                                 </ol>*/
/*                             </div>*/
/*                             <div class="sidebar-module sidebar-module-inset">*/
/*                                 <h4>Tags</h4>*/
/*                                 {{ render(controller('AppBundle:Default:showTagList')) }}*/
/*                             </div>*/
/*                         </div>    */
/*                     </div>*/
/*                 </div>*/
/*             {% elseif post is aninstanceof('AppBundle\\Entity\\Imagegalleries')%}    */
/*                 Gallery*/
/*             {% endif %}*/
/*         {% endfor %}*/
/*     {% endblock %}*/
/* */
/*     {% block javascripts %}*/
/*         {{ parent() }}*/
/*         <script src="{{ asset('assets/vendor/blueimp/js/blueimp-gallery.js') }}"></script>*/
/*         <script src="{{ asset('assets/vendor/blueimp/js/bootstrap-image-gallery.js') }}"></script>*/
/*     {% endblock %}*/
/* */
