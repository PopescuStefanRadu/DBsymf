<?php

/* default/index.html.twig */
class __TwigTemplate_5bc31d4c0c992835fe746ddde1bfdd306f0d80753f16958bd4705d0707d39197 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c09764bae8fa461002deaada162201d18f4e28fe3b1ed40bd6876006fe08f16a = $this->env->getExtension("native_profiler");
        $__internal_c09764bae8fa461002deaada162201d18f4e28fe3b1ed40bd6876006fe08f16a->enter($__internal_c09764bae8fa461002deaada162201d18f4e28fe3b1ed40bd6876006fe08f16a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c09764bae8fa461002deaada162201d18f4e28fe3b1ed40bd6876006fe08f16a->leave($__internal_c09764bae8fa461002deaada162201d18f4e28fe3b1ed40bd6876006fe08f16a_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1c089ce2c7f52a705988a54bbd2f941bf0c000ad24447a8e10c1e2ed56726fb3 = $this->env->getExtension("native_profiler");
        $__internal_1c089ce2c7f52a705988a54bbd2f941bf0c000ad24447a8e10c1e2ed56726fb3->enter($__internal_1c089ce2c7f52a705988a54bbd2f941bf0c000ad24447a8e10c1e2ed56726fb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/blog.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/css/blueimp-gallery.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/css/bootstrap-image-gallery.css"), "html", null, true);
        echo "\"/>
";
        
        $__internal_1c089ce2c7f52a705988a54bbd2f941bf0c000ad24447a8e10c1e2ed56726fb3->leave($__internal_1c089ce2c7f52a705988a54bbd2f941bf0c000ad24447a8e10c1e2ed56726fb3_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_71cf252409e0565255dd3f2b104157bc097f013a87c9daebd79974c3b4f2cde7 = $this->env->getExtension("native_profiler");
        $__internal_71cf252409e0565255dd3f2b104157bc097f013a87c9daebd79974c3b4f2cde7->enter($__internal_71cf252409e0565255dd3f2b104157bc097f013a87c9daebd79974c3b4f2cde7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 12
        echo twig_include($this->env, $context, "default/posts.html.twig", array("posts" => (isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts"))));
        echo "
";
        
        $__internal_71cf252409e0565255dd3f2b104157bc097f013a87c9daebd79974c3b4f2cde7->leave($__internal_71cf252409e0565255dd3f2b104157bc097f013a87c9daebd79974c3b4f2cde7_prof);

    }

    // line 15
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_55b3a6e1dddee78880927fdbc690b6bdb9dccac7b5e885a92dc92e71fa348287 = $this->env->getExtension("native_profiler");
        $__internal_55b3a6e1dddee78880927fdbc690b6bdb9dccac7b5e885a92dc92e71fa348287->enter($__internal_55b3a6e1dddee78880927fdbc690b6bdb9dccac7b5e885a92dc92e71fa348287_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 16
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/js/blueimp-gallery.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/js/bootstrap-image-gallery.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_55b3a6e1dddee78880927fdbc690b6bdb9dccac7b5e885a92dc92e71fa348287->leave($__internal_55b3a6e1dddee78880927fdbc690b6bdb9dccac7b5e885a92dc92e71fa348287_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 18,  95 => 17,  90 => 16,  84 => 15,  75 => 12,  70 => 11,  64 => 10,  55 => 7,  51 => 6,  47 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block stylesheets %}*/
/*     {{ parent() }}*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/blog.css')}}"/>*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/vendor/blueimp/css/blueimp-gallery.css') }}"/>*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/vendor/blueimp/css/bootstrap-image-gallery.css') }}"/>*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {{ parent() }}*/
/*     {{include('default/posts.html.twig', { 'posts': posts })}}*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {{ parent() }}*/
/*     <script src="{{ asset('assets/vendor/blueimp/js/blueimp-gallery.js') }}"></script>*/
/*     <script src="{{ asset('assets/vendor/blueimp/js/bootstrap-image-gallery.js') }}"></script>*/
/* {% endblock %}*/
