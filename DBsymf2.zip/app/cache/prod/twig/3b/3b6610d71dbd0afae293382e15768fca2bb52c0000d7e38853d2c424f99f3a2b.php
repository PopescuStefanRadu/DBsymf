<?php

/* default/posts.html.twig */
class __TwigTemplate_6cf3bf7b6a6519ba0c72e47b5b8afc76fe3783b3fecd362bfc5665c08d8c06d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"container\">
    <div class=\"row\">
        <div class=\"col-sm-8 blog-main\">
            ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 5
            echo "                ";
            if ($this->env->getExtension('app_extension')->theinstanceof($context["post"], "AppBundle\\Entity\\Threads")) {
                // line 6
                echo "                    ";
                echo twig_include($this->env, $context, "default/thread.html.twig", array("post" => $context["post"]));
                echo "
                ";
            } elseif ($this->env->getExtension('app_extension')->theinstanceof(            // line 7
$context["post"], "AppBundle\\Entity\\Imagegalleries")) {
                echo "    
                    ";
                // line 8
                echo twig_include($this->env, $context, "default/gallery.html.twig", array("post" => $context["post"]));
                echo "
                ";
            }
            // line 10
            echo "            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 11
        echo "        </div>
        <div class=\"col-sm-3 col-sm-offset-1 blog-sidebar\">

            ";
        // line 14
        if ($this->env->getExtension('security')->isGranted("ROLE_AUTHOR")) {
            // line 15
            echo "                <div class=\"sidebar-module\">
                    <a class=\"btn btn-default btn-block\" href=\"";
            // line 16
            echo $this->env->getExtension('routing')->getPath("add_thread");
            echo "\">Posteaza un thread</a>
                    <a class=\"btn btn-default btn-block\" href=\"\">Posteaza o galerie</a>
                </div>
            ";
        }
        // line 20
        echo "            <div class=\"sidebar-module sidebar-module-inset\">
                <h4>Something</h4>
                <p>Etiam porta <em>sem malesuada magna</em> mollis euismod. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.</p>
            </div>
            <div class=\"sidebar-module sidebar-module-inset\">
                <h4>Tags</h4>
                <ol class=\"list-unstyled\">
                    <li><a href=\"#\">Placeholders</a></li>
                    <li><a href=\"#\">Placeholders</a></li>
                    <li><a href=\"#\">Placeholders</a></li>
                    <li><a href=\"#\">Placeholders</a></li>
                    <li><a href=\"#\">Placeholders</a></li>
                    <li><a href=\"#\">Placeholders</a></li>
                    <li><a href=\"#\">Placeholders</a></li>
                </ol>
            </div>
        </div>
    </div>
</div>";
    }

    public function getTemplateName()
    {
        return "default/posts.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  89 => 20,  82 => 16,  79 => 15,  77 => 14,  72 => 11,  58 => 10,  53 => 8,  49 => 7,  44 => 6,  41 => 5,  24 => 4,  19 => 1,);
    }
}
/* <div class="container">*/
/*     <div class="row">*/
/*         <div class="col-sm-8 blog-main">*/
/*             {% for post in posts %}*/
/*                 {% if post is aninstanceof('AppBundle\\Entity\\Threads') %}*/
/*                     {{include('default/thread.html.twig', { 'post': post })}}*/
/*                 {% elseif post is aninstanceof('AppBundle\\Entity\\Imagegalleries')%}    */
/*                     {{include('default/gallery.html.twig', {'post':post})}}*/
/*                 {% endif %}*/
/*             {% endfor%}*/
/*         </div>*/
/*         <div class="col-sm-3 col-sm-offset-1 blog-sidebar">*/
/* */
/*             {% if is_granted('ROLE_AUTHOR')%}*/
/*                 <div class="sidebar-module">*/
/*                     <a class="btn btn-default btn-block" href="{{path('add_thread')}}">Posteaza un thread</a>*/
/*                     <a class="btn btn-default btn-block" href="">Posteaza o galerie</a>*/
/*                 </div>*/
/*             {% endif %}*/
/*             <div class="sidebar-module sidebar-module-inset">*/
/*                 <h4>Something</h4>*/
/*                 <p>Etiam porta <em>sem malesuada magna</em> mollis euismod. Cras mattis consectetur purus sit amet fermentum. Aenean lacinia bibendum nulla sed consectetur.</p>*/
/*             </div>*/
/*             <div class="sidebar-module sidebar-module-inset">*/
/*                 <h4>Tags</h4>*/
/*                 <ol class="list-unstyled">*/
/*                     <li><a href="#">Placeholders</a></li>*/
/*                     <li><a href="#">Placeholders</a></li>*/
/*                     <li><a href="#">Placeholders</a></li>*/
/*                     <li><a href="#">Placeholders</a></li>*/
/*                     <li><a href="#">Placeholders</a></li>*/
/*                     <li><a href="#">Placeholders</a></li>*/
/*                     <li><a href="#">Placeholders</a></li>*/
/*                 </ol>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* </div>*/
