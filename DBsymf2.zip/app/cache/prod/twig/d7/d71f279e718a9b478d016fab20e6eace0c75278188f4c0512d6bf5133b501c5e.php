<?php

/* default/posts.html.twig */
class __TwigTemplate_63b7e45f28a55889cb57a13ba456943a72e60af01c0ac3a38070a9c4313a55c1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bd22e6e589ed630615685f42860b785716a8ee0e1d239c58bf2bdf40edf10a7b = $this->env->getExtension("native_profiler");
        $__internal_bd22e6e589ed630615685f42860b785716a8ee0e1d239c58bf2bdf40edf10a7b->enter($__internal_bd22e6e589ed630615685f42860b785716a8ee0e1d239c58bf2bdf40edf10a7b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/posts.html.twig"));

        // line 1
        echo "<div class=\"container main\">
    <div class=\"row\">
        <div class=\"col-sm-9\">
            <div class=\"blog-main\">
                ";
        // line 5
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 6
            echo "                    ";
            if ($this->env->getExtension('app_extension')->theinstanceof($context["post"], "AppBundle\\Entity\\Threads")) {
                // line 7
                echo "                        ";
                echo twig_include($this->env, $context, "default/thread.html.twig", array("post" => $context["post"]));
                echo "
                    ";
            } elseif ($this->env->getExtension('app_extension')->theinstanceof(            // line 8
$context["post"], "AppBundle\\Entity\\Imagegalleries")) {
                echo "    
                        ";
                // line 9
                echo twig_include($this->env, $context, "default/gallery.html.twig", array("post" => $context["post"]));
                echo "
                    ";
            }
            // line 11
            echo "                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        echo "            </div>
        </div>
        <div class=\"col-sm-3\">
            <div class=\"blog-sidebar\">
                ";
        // line 16
        if ($this->env->getExtension('security')->isGranted("ROLE_AUTHOR")) {
            // line 17
            echo "                    <div class=\"sidebar-module sidebar-module-inset\">
                        <a class=\"btn btn-default btn-block\" href=\"";
            // line 18
            echo $this->env->getExtension('routing')->getPath("add_thread");
            echo "\">Posteaza un thread</a>
                        <a class=\"btn btn-default btn-block\" href=\"\">Posteaza o galerie</a>
                    </div>
                ";
        }
        // line 22
        echo "                <div class=\"sidebar-module sidebar-module-inset\">
                    <h4>Siteuri asociate</h4>
                    <ol class=\"list-unstyled\">
                        <li><a href=\"https://www.facebook.com/iulia.drache\">Facebook Iulia Albota</a></li>
                        <li><a href=\"https://www.facebook.com/Sec%C8%9Bia-14-grup-literar-996081047120103/\">Facebook Sectia 14</a></li>
                    </ol>
                </div>
                <div class=\"sidebar-module sidebar-module-inset\">
                    <h4>Tags</h4>
                    ";
        // line 31
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppBundle:Default:showTagList"));
        echo "
                </div>
            </div>
        </div>
    </div>
</div>";
        
        $__internal_bd22e6e589ed630615685f42860b785716a8ee0e1d239c58bf2bdf40edf10a7b->leave($__internal_bd22e6e589ed630615685f42860b785716a8ee0e1d239c58bf2bdf40edf10a7b_prof);

    }

    public function getTemplateName()
    {
        return "default/posts.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  105 => 31,  94 => 22,  87 => 18,  84 => 17,  82 => 16,  76 => 12,  62 => 11,  57 => 9,  53 => 8,  48 => 7,  45 => 6,  28 => 5,  22 => 1,);
    }
}
/* <div class="container main">*/
/*     <div class="row">*/
/*         <div class="col-sm-9">*/
/*             <div class="blog-main">*/
/*                 {% for post in posts %}*/
/*                     {% if post is aninstanceof('AppBundle\\Entity\\Threads') %}*/
/*                         {{include('default/thread.html.twig', { 'post': post })}}*/
/*                     {% elseif post is aninstanceof('AppBundle\\Entity\\Imagegalleries')%}    */
/*                         {{include('default/gallery.html.twig', {'post':post})}}*/
/*                     {% endif %}*/
/*                 {% endfor%}*/
/*             </div>*/
/*         </div>*/
/*         <div class="col-sm-3">*/
/*             <div class="blog-sidebar">*/
/*                 {% if is_granted('ROLE_AUTHOR')%}*/
/*                     <div class="sidebar-module sidebar-module-inset">*/
/*                         <a class="btn btn-default btn-block" href="{{path('add_thread')}}">Posteaza un thread</a>*/
/*                         <a class="btn btn-default btn-block" href="">Posteaza o galerie</a>*/
/*                     </div>*/
/*                 {% endif %}*/
/*                 <div class="sidebar-module sidebar-module-inset">*/
/*                     <h4>Siteuri asociate</h4>*/
/*                     <ol class="list-unstyled">*/
/*                         <li><a href="https://www.facebook.com/iulia.drache">Facebook Iulia Albota</a></li>*/
/*                         <li><a href="https://www.facebook.com/Sec%C8%9Bia-14-grup-literar-996081047120103/">Facebook Sectia 14</a></li>*/
/*                     </ol>*/
/*                 </div>*/
/*                 <div class="sidebar-module sidebar-module-inset">*/
/*                     <h4>Tags</h4>*/
/*                     {{ render(controller('AppBundle:Default:showTagList')) }}*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* </div>*/
