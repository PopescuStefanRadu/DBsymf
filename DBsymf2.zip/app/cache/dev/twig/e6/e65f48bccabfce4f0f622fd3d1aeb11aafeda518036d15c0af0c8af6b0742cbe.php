<?php

/* default/index.html.twig */
class __TwigTemplate_e62f0ef20b25bb9741e1b60f4f54eba3dc4cbb48c61ac218df18f49c255b1ea8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_14fc09eab22258e31b4ef0450cc3df8535c884e9a1b633e83596de0f4c035b86 = $this->env->getExtension("native_profiler");
        $__internal_14fc09eab22258e31b4ef0450cc3df8535c884e9a1b633e83596de0f4c035b86->enter($__internal_14fc09eab22258e31b4ef0450cc3df8535c884e9a1b633e83596de0f4c035b86_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_14fc09eab22258e31b4ef0450cc3df8535c884e9a1b633e83596de0f4c035b86->leave($__internal_14fc09eab22258e31b4ef0450cc3df8535c884e9a1b633e83596de0f4c035b86_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_36ad21b7136366e27944c89e6f1cbbbfc18a55009f19abf3e50c4f6760f6af54 = $this->env->getExtension("native_profiler");
        $__internal_36ad21b7136366e27944c89e6f1cbbbfc18a55009f19abf3e50c4f6760f6af54->enter($__internal_36ad21b7136366e27944c89e6f1cbbbfc18a55009f19abf3e50c4f6760f6af54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/blog.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/css/blueimp-gallery.css"), "html", null, true);
        echo "\"/>
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/css/bootstrap-image-gallery.css"), "html", null, true);
        echo "\"/>
";
        
        $__internal_36ad21b7136366e27944c89e6f1cbbbfc18a55009f19abf3e50c4f6760f6af54->leave($__internal_36ad21b7136366e27944c89e6f1cbbbfc18a55009f19abf3e50c4f6760f6af54_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_1cb4a96300e70351bd9f6155857371dde1765bdb6953696c17f213cd68b7255f = $this->env->getExtension("native_profiler");
        $__internal_1cb4a96300e70351bd9f6155857371dde1765bdb6953696c17f213cd68b7255f->enter($__internal_1cb4a96300e70351bd9f6155857371dde1765bdb6953696c17f213cd68b7255f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 11
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 12
        echo twig_include($this->env, $context, "default/posts.html.twig", array("posts" => (isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts"))));
        echo "
";
        
        $__internal_1cb4a96300e70351bd9f6155857371dde1765bdb6953696c17f213cd68b7255f->leave($__internal_1cb4a96300e70351bd9f6155857371dde1765bdb6953696c17f213cd68b7255f_prof);

    }

    // line 15
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_d91394a0235556e8a886486c1fb231d7a591c68265d26fd976823117a98c3754 = $this->env->getExtension("native_profiler");
        $__internal_d91394a0235556e8a886486c1fb231d7a591c68265d26fd976823117a98c3754->enter($__internal_d91394a0235556e8a886486c1fb231d7a591c68265d26fd976823117a98c3754_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 16
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
    <script src=\"";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/js/blueimp-gallery.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 18
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/blueimp/js/bootstrap-image-gallery.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_d91394a0235556e8a886486c1fb231d7a591c68265d26fd976823117a98c3754->leave($__internal_d91394a0235556e8a886486c1fb231d7a591c68265d26fd976823117a98c3754_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 18,  95 => 17,  90 => 16,  84 => 15,  75 => 12,  70 => 11,  64 => 10,  55 => 7,  51 => 6,  47 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block stylesheets %}*/
/*     {{ parent() }}*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/blog.css')}}"/>*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/vendor/blueimp/css/blueimp-gallery.css') }}"/>*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/vendor/blueimp/css/bootstrap-image-gallery.css') }}"/>*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {{ parent() }}*/
/*     {{include('default/posts.html.twig', { 'posts': posts })}}*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {{ parent() }}*/
/*     <script src="{{ asset('assets/vendor/blueimp/js/blueimp-gallery.js') }}"></script>*/
/*     <script src="{{ asset('assets/vendor/blueimp/js/bootstrap-image-gallery.js') }}"></script>*/
/* {% endblock %}*/
