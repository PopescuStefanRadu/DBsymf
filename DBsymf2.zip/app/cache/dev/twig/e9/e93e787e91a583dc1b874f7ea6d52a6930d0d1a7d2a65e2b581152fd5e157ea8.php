<?php

/* default/index.html.twig */
class __TwigTemplate_9fb7cc1848e06e5d0df815fc0ea1248ec32b0573b96472b37da1bf5b5d39c561 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d171824841a002009f003244f1996a51671c3a553a8b1608aca449f84f40cc74 = $this->env->getExtension("native_profiler");
        $__internal_d171824841a002009f003244f1996a51671c3a553a8b1608aca449f84f40cc74->enter($__internal_d171824841a002009f003244f1996a51671c3a553a8b1608aca449f84f40cc74_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_d171824841a002009f003244f1996a51671c3a553a8b1608aca449f84f40cc74->leave($__internal_d171824841a002009f003244f1996a51671c3a553a8b1608aca449f84f40cc74_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_d83dc37ebecfc8a75dba570cf551f5b0acf2b1f6bbbec0536043a37eda3d8770 = $this->env->getExtension("native_profiler");
        $__internal_d83dc37ebecfc8a75dba570cf551f5b0acf2b1f6bbbec0536043a37eda3d8770->enter($__internal_d83dc37ebecfc8a75dba570cf551f5b0acf2b1f6bbbec0536043a37eda3d8770_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/blog.css"), "html", null, true);
        echo "\"/>
";
        
        $__internal_d83dc37ebecfc8a75dba570cf551f5b0acf2b1f6bbbec0536043a37eda3d8770->leave($__internal_d83dc37ebecfc8a75dba570cf551f5b0acf2b1f6bbbec0536043a37eda3d8770_prof);

    }

    // line 8
    public function block_body($context, array $blocks = array())
    {
        $__internal_53e08fc90e75bb3d99f8f902909830d492572fbb8bad21dd19f98638848382d8 = $this->env->getExtension("native_profiler");
        $__internal_53e08fc90e75bb3d99f8f902909830d492572fbb8bad21dd19f98638848382d8->enter($__internal_53e08fc90e75bb3d99f8f902909830d492572fbb8bad21dd19f98638848382d8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 9
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container\">
    </div>

    ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 14
            echo "        ";
            if ($this->env->getExtension('app_extension')->theinstanceof($context["post"], "AppBundle\\Entity\\Threads")) {
                // line 15
                echo "            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"blog-main\">
                        <div class=\"blog-post\">
                            <h2 class=\"blog-post-title\">
                                <a href=\"";
                // line 20
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("post_title", array("pid" => $this->getAttribute($context["post"], "x", array()), "ptitle" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($context["post"], "title", array())))), "html", null, true);
                echo "\">
                                    ";
                // line 21
                echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
                echo "</a>
                            </h2>
                            <p class=\"blog-post-meta\">";
                // line 23
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "dateTime", array()), "d/m/Y H:i"), "html", null, true);
                echo " by <a href=\"#\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["post"], "user", array()), "username", array()), "html", null, true);
                echo "</a></p>
                            ";
                // line 24
                echo twig_escape_filter($this->env, $this->env->getExtension('first_paragraph')->firstParagraph($this->getAttribute($context["post"], "content", array())), "html", null, true);
                echo "
                        </div>
                    </div>
                </div>
            </div>
        ";
            } elseif ($this->env->getExtension('app_extension')->theinstanceof(            // line 29
$context["post"], "AppBundle\\Entity\\Imagegalleries")) {
                echo "    
            Gallery
        ";
            }
            // line 32
            echo "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_53e08fc90e75bb3d99f8f902909830d492572fbb8bad21dd19f98638848382d8->leave($__internal_53e08fc90e75bb3d99f8f902909830d492572fbb8bad21dd19f98638848382d8_prof);

    }

    // line 36
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_ff7d538172c4d2626dd0f6ca600d017ccc8e9ea4f36bdcb234f9af45d2b218af = $this->env->getExtension("native_profiler");
        $__internal_ff7d538172c4d2626dd0f6ca600d017ccc8e9ea4f36bdcb234f9af45d2b218af->enter($__internal_ff7d538172c4d2626dd0f6ca600d017ccc8e9ea4f36bdcb234f9af45d2b218af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 37
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
";
        
        $__internal_ff7d538172c4d2626dd0f6ca600d017ccc8e9ea4f36bdcb234f9af45d2b218af->leave($__internal_ff7d538172c4d2626dd0f6ca600d017ccc8e9ea4f36bdcb234f9af45d2b218af_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  131 => 37,  125 => 36,  113 => 32,  107 => 29,  99 => 24,  93 => 23,  88 => 21,  84 => 20,  77 => 15,  74 => 14,  70 => 13,  62 => 9,  56 => 8,  47 => 5,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block stylesheets %}*/
/*     {{ parent() }}*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/blog.css')}}"/>*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {{ parent() }}*/
/*     <div class="container">*/
/*     </div>*/
/* */
/*     {% for post in posts %}*/
/*         {% if post is aninstanceof('AppBundle\\Entity\\Threads') %}*/
/*             <div class="container">*/
/*                 <div class="row">*/
/*                     <div class="blog-main">*/
/*                         <div class="blog-post">*/
/*                             <h2 class="blog-post-title">*/
/*                                 <a href="{{path('post_title',{'pid':post.x,'ptitle':post.title|makeLink})}}">*/
/*                                     {{post.title}}</a>*/
/*                             </h2>*/
/*                             <p class="blog-post-meta">{{post.dateTime|date('d/m/Y H:i')}} by <a href="#">{{post.user.username}}</a></p>*/
/*                             {{post.content|firstParagraph}}*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         {% elseif post is aninstanceof('AppBundle\\Entity\\Imagegalleries')%}    */
/*             Gallery*/
/*         {% endif %}*/
/* */
/*     {% endfor%}*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
