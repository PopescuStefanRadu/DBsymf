<?php

/* default/post.html.twig */
class __TwigTemplate_77ee390ae8c31e9f890e626a168bc84f29add645c59889083133f334a4250e4a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/post.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_13c59b311c9a9fd90578fad79df1c008b8cee3a5beb61dc5814e4d2ebe098cb3 = $this->env->getExtension("native_profiler");
        $__internal_13c59b311c9a9fd90578fad79df1c008b8cee3a5beb61dc5814e4d2ebe098cb3->enter($__internal_13c59b311c9a9fd90578fad79df1c008b8cee3a5beb61dc5814e4d2ebe098cb3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/post.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_13c59b311c9a9fd90578fad79df1c008b8cee3a5beb61dc5814e4d2ebe098cb3->leave($__internal_13c59b311c9a9fd90578fad79df1c008b8cee3a5beb61dc5814e4d2ebe098cb3_prof);

    }

    // line 2
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_f861b90d1663026b98b96e128c51a9f50f044c4c1415820d9ce1a56204d64d09 = $this->env->getExtension("native_profiler");
        $__internal_f861b90d1663026b98b96e128c51a9f50f044c4c1415820d9ce1a56204d64d09->enter($__internal_f861b90d1663026b98b96e128c51a9f50f044c4c1415820d9ce1a56204d64d09_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 3
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
    <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/blog.css"), "html", null, true);
        echo "\"/>
";
        
        $__internal_f861b90d1663026b98b96e128c51a9f50f044c4c1415820d9ce1a56204d64d09->leave($__internal_f861b90d1663026b98b96e128c51a9f50f044c4c1415820d9ce1a56204d64d09_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_91771fc44586f666eacd7554bbc7afa19882465baa71c7dd5af64b8604856a3b = $this->env->getExtension("native_profiler");
        $__internal_91771fc44586f666eacd7554bbc7afa19882465baa71c7dd5af64b8604856a3b->enter($__internal_91771fc44586f666eacd7554bbc7afa19882465baa71c7dd5af64b8604856a3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["posts"]) ? $context["posts"] : $this->getContext($context, "posts")));
        foreach ($context['_seq'] as $context["_key"] => $context["post"]) {
            // line 10
            echo "        ";
            if ($this->env->getExtension('app_extension')->theinstanceof($context["post"], "AppBundle\\Entity\\Threads")) {
                // line 11
                echo "            <div class=\"container\">
                <div class=\"row\">
                    <div class=\"blog-main\">
                        <div class=\"blog-post\">
                            <h2 class=\"blog-post-title\">
                                <a href=\"";
                // line 16
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("post_title", array("pid" => $this->getAttribute($context["post"], "x", array()), "ptitle" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($context["post"], "title", array())))), "html", null, true);
                echo "\">
                                    ";
                // line 17
                echo twig_escape_filter($this->env, $this->getAttribute($context["post"], "title", array()), "html", null, true);
                echo "</a>
                            </h2>
                            <p class=\"blog-post-meta\">
                                ";
                // line 20
                echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute($context["post"], "dateTime", array()), "d/m/Y H:i"), "html", null, true);
                echo " by <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("user_profile_name", array("profileid" => $this->getAttribute($this->getAttribute($context["post"], "user", array()), "id", array()), "profilename" => $this->getAttribute($this->getAttribute($context["post"], "user", array()), "username", array()))), "html", null, true);
                echo "\">
                                    ";
                // line 21
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["post"], "user", array()), "username", array()), "html", null, true);
                echo "
                                </a>
                            <br>
                            ";
                // line 24
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["post"], "postTagsList", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["posttag"]) {
                    // line 25
                    echo "                                <a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("tags_name", array("tagid" => $this->getAttribute($this->getAttribute($context["posttag"], "tag", array()), "x", array()), "tagname" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($this->getAttribute($context["posttag"], "tag", array()), "title", array())))), "html", null, true);
                    echo "\"><span class=\"tag\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["posttag"], "tag", array()), "title", array()), "html", null, true);
                    echo "</span></a>
                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['posttag'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 27
                echo "                            </p>
                            ";
                // line 28
                echo $this->env->getExtension('parsedown')->parsedown($this->getAttribute($context["post"], "content", array()));
                echo "
                        </div>
                    </div>
                </div>
            </div>
        ";
            } elseif ($this->env->getExtension('app_extension')->theinstanceof(            // line 33
$context["post"], "AppBundle\\Entity\\Imagegalleries")) {
                echo "    
            Gallery
        ";
            }
            // line 36
            echo "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['post'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_91771fc44586f666eacd7554bbc7afa19882465baa71c7dd5af64b8604856a3b->leave($__internal_91771fc44586f666eacd7554bbc7afa19882465baa71c7dd5af64b8604856a3b_prof);

    }

    // line 39
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_066ee7d21e1df71162ddda0e027995db3c53fbad79f88315da0f2670c102f0a9 = $this->env->getExtension("native_profiler");
        $__internal_066ee7d21e1df71162ddda0e027995db3c53fbad79f88315da0f2670c102f0a9->enter($__internal_066ee7d21e1df71162ddda0e027995db3c53fbad79f88315da0f2670c102f0a9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 40
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
";
        
        $__internal_066ee7d21e1df71162ddda0e027995db3c53fbad79f88315da0f2670c102f0a9->leave($__internal_066ee7d21e1df71162ddda0e027995db3c53fbad79f88315da0f2670c102f0a9_prof);

    }

    public function getTemplateName()
    {
        return "default/post.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 40,  146 => 39,  135 => 36,  129 => 33,  121 => 28,  118 => 27,  107 => 25,  103 => 24,  97 => 21,  91 => 20,  85 => 17,  81 => 16,  74 => 11,  71 => 10,  67 => 9,  62 => 8,  56 => 7,  47 => 4,  42 => 3,  36 => 2,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* {% block stylesheets %}*/
/*     {{ parent() }}*/
/*     <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/blog.css')}}"/>*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {{ parent() }}*/
/*     {% for post in posts %}*/
/*         {% if post is aninstanceof('AppBundle\\Entity\\Threads') %}*/
/*             <div class="container">*/
/*                 <div class="row">*/
/*                     <div class="blog-main">*/
/*                         <div class="blog-post">*/
/*                             <h2 class="blog-post-title">*/
/*                                 <a href="{{path('post_title',{'pid':post.x,'ptitle':post.title|makeLink})}}">*/
/*                                     {{post.title}}</a>*/
/*                             </h2>*/
/*                             <p class="blog-post-meta">*/
/*                                 {{post.dateTime|date('d/m/Y H:i')}} by <a href="{{path('user_profile_name',{'profileid':post.user.id,'profilename':post.user.username})}}">*/
/*                                     {{post.user.username}}*/
/*                                 </a>*/
/*                             <br>*/
/*                             {% for posttag in post.postTagsList %}*/
/*                                 <a href="{{path('tags_name',{'tagid':posttag.tag.x,'tagname':posttag.tag.title|makeLink})}}"><span class="tag">{{ posttag.tag.title }}</span></a>*/
/*                                 {% endfor %}*/
/*                             </p>*/
/*                             {{post.content|parsedown}}*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         {% elseif post is aninstanceof('AppBundle\\Entity\\Imagegalleries')%}    */
/*             Gallery*/
/*         {% endif %}*/
/*     {% endfor %}*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
