<?php

/* default/thread.html.twig */
class __TwigTemplate_569324738ac747a285c95baac91adecae7e76b7d075e0c7b3155ddfd266e3b66 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78baab8e329920ae65e0fab285032c9cb014832cb10e84413192eacb7eb7084f = $this->env->getExtension("native_profiler");
        $__internal_78baab8e329920ae65e0fab285032c9cb014832cb10e84413192eacb7eb7084f->enter($__internal_78baab8e329920ae65e0fab285032c9cb014832cb10e84413192eacb7eb7084f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/thread.html.twig"));

        // line 1
        echo "<div class=\"blog-post\">
    <h2 class=\"blog-post-title\">
        <a href=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("post_title", array("pid" => $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "x", array()), "ptitle" => $this->env->getExtension('make_link')->makeLink($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "title", array())))), "html", null, true);
        echo "\">
            ";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "title", array()), "html", null, true);
        echo "</a>
    </h2>
    <p class=\"blog-post-meta\">";
        // line 6
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, $this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "dateTime", array()), "d/m/Y H:i"), "html", null, true);
        echo " by <a href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("user_profile_name", array("profileid" => $this->getAttribute($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "user", array()), "id", array()), "profilename" => $this->getAttribute($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "user", array()), "username", array()))), "html", null, true);
        echo "\">
            ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "user", array()), "username", array()), "html", null, true);
        echo "
        </a><br>
        ";
        // line 9
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "postTagsList", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["posttag"]) {
            // line 10
            echo "            <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("tags_name", array("tagid" => $this->getAttribute($this->getAttribute($context["posttag"], "tag", array()), "x", array()), "tagname" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($this->getAttribute($context["posttag"], "tag", array()), "title", array())))), "html", null, true);
            echo "\"><span class=\"tag\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["posttag"], "tag", array()), "title", array()), "html", null, true);
            echo "</span></a>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['posttag'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 12
        echo "    </p>

    ";
        // line 14
        echo $this->env->getExtension('parsedown')->parsedown($this->env->getExtension('first_paragraph')->firstParagraph($this->getAttribute((isset($context["post"]) ? $context["post"] : $this->getContext($context, "post")), "content", array())));
        echo "
</div>
<hr>";
        
        $__internal_78baab8e329920ae65e0fab285032c9cb014832cb10e84413192eacb7eb7084f->leave($__internal_78baab8e329920ae65e0fab285032c9cb014832cb10e84413192eacb7eb7084f_prof);

    }

    public function getTemplateName()
    {
        return "default/thread.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  65 => 14,  61 => 12,  50 => 10,  46 => 9,  41 => 7,  35 => 6,  30 => 4,  26 => 3,  22 => 1,);
    }
}
/* <div class="blog-post">*/
/*     <h2 class="blog-post-title">*/
/*         <a href="{{path('post_title',{'pid':post.x,'ptitle':post.title|makeLink})}}">*/
/*             {{post.title}}</a>*/
/*     </h2>*/
/*     <p class="blog-post-meta">{{post.dateTime|date('d/m/Y H:i')}} by <a href="{{path('user_profile_name',{'profileid':post.user.id,'profilename':post.user.username})}}">*/
/*             {{post.user.username}}*/
/*         </a><br>*/
/*         {% for posttag in post.postTagsList %}*/
/*             <a href="{{path('tags_name',{'tagid':posttag.tag.x,'tagname':posttag.tag.title|makeLink})}}"><span class="tag">{{ posttag.tag.title }}</span></a>*/
/*         {% endfor %}*/
/*     </p>*/
/* */
/*     {{post.content|firstParagraph|parsedown}}*/
/* </div>*/
/* <hr>*/
