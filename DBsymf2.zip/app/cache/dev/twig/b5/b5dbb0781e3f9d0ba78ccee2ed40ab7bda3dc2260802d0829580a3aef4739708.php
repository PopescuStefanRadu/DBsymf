<?php

/* base.html.twig */
class __TwigTemplate_c52ec140043a363df411d93b5c6e719f0c02d7c141e6f3ffd45a6dbf8430cc58 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_261575853686a3649eca0f52426d7a63840d160275eb6536f50cc81b9cfb4b39 = $this->env->getExtension("native_profiler");
        $__internal_261575853686a3649eca0f52426d7a63840d160275eb6536f50cc81b9cfb4b39->enter($__internal_261575853686a3649eca0f52426d7a63840d160275eb6536f50cc81b9cfb4b39_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        
        <title>";
        // line 6
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 7
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 11
        echo "        
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/img/mysql.png"), "html", null, true);
        echo "\" />

    </head>
    <body>
        ";
        // line 16
        $this->displayBlock('body', $context, $blocks);
        // line 19
        echo "

        ";
        // line 21
        $this->displayBlock('javascripts', $context, $blocks);
        // line 25
        echo "    </body>
</html>
";
        
        $__internal_261575853686a3649eca0f52426d7a63840d160275eb6536f50cc81b9cfb4b39->leave($__internal_261575853686a3649eca0f52426d7a63840d160275eb6536f50cc81b9cfb4b39_prof);

    }

    // line 6
    public function block_title($context, array $blocks = array())
    {
        $__internal_c272004488caff1c41e0e014dbc5f7aa1d5e8823d939bef5c13e96928b0d805b = $this->env->getExtension("native_profiler");
        $__internal_c272004488caff1c41e0e014dbc5f7aa1d5e8823d939bef5c13e96928b0d805b->enter($__internal_c272004488caff1c41e0e014dbc5f7aa1d5e8823d939bef5c13e96928b0d805b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "DBProject";
        
        $__internal_c272004488caff1c41e0e014dbc5f7aa1d5e8823d939bef5c13e96928b0d805b->leave($__internal_c272004488caff1c41e0e014dbc5f7aa1d5e8823d939bef5c13e96928b0d805b_prof);

    }

    // line 7
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_621d4d14f576be183a76e1b008666a3612cb6a13a817b4de48d21cc3085c55b4 = $this->env->getExtension("native_profiler");
        $__internal_621d4d14f576be183a76e1b008666a3612cb6a13a817b4de48d21cc3085c55b4->enter($__internal_621d4d14f576be183a76e1b008666a3612cb6a13a817b4de48d21cc3085c55b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 8
        echo "            <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/bootstrap_1.css"), "html", null, true);
        echo "\"/>
            <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/base.css"), "html", null, true);
        echo "\"/>
        ";
        
        $__internal_621d4d14f576be183a76e1b008666a3612cb6a13a817b4de48d21cc3085c55b4->leave($__internal_621d4d14f576be183a76e1b008666a3612cb6a13a817b4de48d21cc3085c55b4_prof);

    }

    // line 16
    public function block_body($context, array $blocks = array())
    {
        $__internal_51777bf7b837ab1195a8da8065b0fb0b40340cb6a9c3fcf6f1d5345b9a1106f8 = $this->env->getExtension("native_profiler");
        $__internal_51777bf7b837ab1195a8da8065b0fb0b40340cb6a9c3fcf6f1d5345b9a1106f8->enter($__internal_51777bf7b837ab1195a8da8065b0fb0b40340cb6a9c3fcf6f1d5345b9a1106f8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 17
        echo "            ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppBundle:Default:navigation"));
        echo "
        ";
        
        $__internal_51777bf7b837ab1195a8da8065b0fb0b40340cb6a9c3fcf6f1d5345b9a1106f8->leave($__internal_51777bf7b837ab1195a8da8065b0fb0b40340cb6a9c3fcf6f1d5345b9a1106f8_prof);

    }

    // line 21
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_f512f17719276e21372bf62919c6d7dbce6f2baae4a17d1d9e690c5978dba4c2 = $this->env->getExtension("native_profiler");
        $__internal_f512f17719276e21372bf62919c6d7dbce6f2baae4a17d1d9e690c5978dba4c2->enter($__internal_f512f17719276e21372bf62919c6d7dbce6f2baae4a17d1d9e690c5978dba4c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 22
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/jquery/dist/jquery.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/bootstrap/dist/js/bootstrap.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_f512f17719276e21372bf62919c6d7dbce6f2baae4a17d1d9e690c5978dba4c2->leave($__internal_f512f17719276e21372bf62919c6d7dbce6f2baae4a17d1d9e690c5978dba4c2_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  125 => 23,  120 => 22,  114 => 21,  104 => 17,  98 => 16,  89 => 9,  84 => 8,  78 => 7,  66 => 6,  57 => 25,  55 => 21,  51 => 19,  49 => 16,  42 => 12,  39 => 11,  37 => 7,  33 => 6,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         */
/*         <title>{% block title %}DBProject{% endblock %}</title>*/
/*         {% block stylesheets %}*/
/*             <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/bootstrap_1.css')}}"/>*/
/*             <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/base.css')}}"/>*/
/*         {% endblock %}*/
/*         */
/*         <link rel="icon" type="image/png" href="{{ asset('assets/public/img/mysql.png') }}" />*/
/* */
/*     </head>*/
/*     <body>*/
/*         {% block body %}*/
/*             {{ render(controller('AppBundle:Default:navigation')) }}*/
/*         {% endblock %}*/
/* */
/* */
/*         {% block javascripts %}*/
/*             <script src="{{ asset('assets/vendor/jquery/dist/jquery.js') }}"></script>*/
/*             <script src="{{ asset('assets/vendor/bootstrap/dist/js/bootstrap.js') }}"></script>*/
/*         {% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
