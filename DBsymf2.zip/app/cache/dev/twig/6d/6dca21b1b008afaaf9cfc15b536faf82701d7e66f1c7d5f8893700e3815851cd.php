<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_9bf599af5a7f0051eaefc4ff0bc6d2c91a5f28d9fd4c6b05c708040830b650f9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9898df5b54dd5b4cc0ed168e77be57b8f0bfe8f0b71c59ca4127d9a0f7861540 = $this->env->getExtension("native_profiler");
        $__internal_9898df5b54dd5b4cc0ed168e77be57b8f0bfe8f0b71c59ca4127d9a0f7861540->enter($__internal_9898df5b54dd5b4cc0ed168e77be57b8f0bfe8f0b71c59ca4127d9a0f7861540_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9898df5b54dd5b4cc0ed168e77be57b8f0bfe8f0b71c59ca4127d9a0f7861540->leave($__internal_9898df5b54dd5b4cc0ed168e77be57b8f0bfe8f0b71c59ca4127d9a0f7861540_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_f1734df80283bfc44f49efa2824cd7546c7a75d4f1a02dcf83ad8c5308a36d64 = $this->env->getExtension("native_profiler");
        $__internal_f1734df80283bfc44f49efa2824cd7546c7a75d4f1a02dcf83ad8c5308a36d64->enter($__internal_f1734df80283bfc44f49efa2824cd7546c7a75d4f1a02dcf83ad8c5308a36d64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_f1734df80283bfc44f49efa2824cd7546c7a75d4f1a02dcf83ad8c5308a36d64->leave($__internal_f1734df80283bfc44f49efa2824cd7546c7a75d4f1a02dcf83ad8c5308a36d64_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_36260ab9d644846b92e53addb31af04303a6d278e75472e294d84895f76495e1 = $this->env->getExtension("native_profiler");
        $__internal_36260ab9d644846b92e53addb31af04303a6d278e75472e294d84895f76495e1->enter($__internal_36260ab9d644846b92e53addb31af04303a6d278e75472e294d84895f76495e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_36260ab9d644846b92e53addb31af04303a6d278e75472e294d84895f76495e1->leave($__internal_36260ab9d644846b92e53addb31af04303a6d278e75472e294d84895f76495e1_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_eb248e4f89dc07b41ef71911b0701b53022db1db1a472a4b439181ef3b314caa = $this->env->getExtension("native_profiler");
        $__internal_eb248e4f89dc07b41ef71911b0701b53022db1db1a472a4b439181ef3b314caa->enter($__internal_eb248e4f89dc07b41ef71911b0701b53022db1db1a472a4b439181ef3b314caa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_eb248e4f89dc07b41ef71911b0701b53022db1db1a472a4b439181ef3b314caa->leave($__internal_eb248e4f89dc07b41ef71911b0701b53022db1db1a472a4b439181ef3b314caa_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
