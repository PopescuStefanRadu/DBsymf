<?php

/* FOSUserBundle::layout.html.twig */
class __TwigTemplate_ce0ce4b204ccf86e83d56653610a82614ae6ca257473e08c5c17ecd996ec9946 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "FOSUserBundle::layout.html.twig", 1);
        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'fos_user_content' => array($this, 'block_fos_user_content'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1c99cd1e323feef3ad06af7e9296429ca2f7ac7affb761e6fbdb45851ca2af36 = $this->env->getExtension("native_profiler");
        $__internal_1c99cd1e323feef3ad06af7e9296429ca2f7ac7affb761e6fbdb45851ca2af36->enter($__internal_1c99cd1e323feef3ad06af7e9296429ca2f7ac7affb761e6fbdb45851ca2af36_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "FOSUserBundle::layout.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1c99cd1e323feef3ad06af7e9296429ca2f7ac7affb761e6fbdb45851ca2af36->leave($__internal_1c99cd1e323feef3ad06af7e9296429ca2f7ac7affb761e6fbdb45851ca2af36_prof);

    }

    // line 3
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_fe388aae20d9449f9a4c79e672fa34519650ed4c455e8ae1eaf79f98aef03e0e = $this->env->getExtension("native_profiler");
        $__internal_fe388aae20d9449f9a4c79e672fa34519650ed4c455e8ae1eaf79f98aef03e0e->enter($__internal_fe388aae20d9449f9a4c79e672fa34519650ed4c455e8ae1eaf79f98aef03e0e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 4
        echo "    ";
        $this->displayParentBlock("stylesheets", $context, $blocks);
        echo "
";
        
        $__internal_fe388aae20d9449f9a4c79e672fa34519650ed4c455e8ae1eaf79f98aef03e0e->leave($__internal_fe388aae20d9449f9a4c79e672fa34519650ed4c455e8ae1eaf79f98aef03e0e_prof);

    }

    // line 7
    public function block_body($context, array $blocks = array())
    {
        $__internal_f2d746e99ad657ea9b3595a34515d0f8ceb1cf19995e2b553790fa762e59fb57 = $this->env->getExtension("native_profiler");
        $__internal_f2d746e99ad657ea9b3595a34515d0f8ceb1cf19995e2b553790fa762e59fb57->enter($__internal_f2d746e99ad657ea9b3595a34515d0f8ceb1cf19995e2b553790fa762e59fb57_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 8
        echo "    ";
        $this->displayParentBlock("body", $context, $blocks);
        echo "
    <div class=\"container\">
    <div>
        ";
        // line 11
        if ($this->env->getExtension('security')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 12
            echo "            ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array())), "FOSUserBundle"), "html", null, true);
            echo " |
            <a href=\"";
            // line 13
            echo $this->env->getExtension('routing')->getPath("fos_user_security_logout");
            echo "\">
                ";
            // line 14
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "
            </a>
        ";
        } else {
            // line 17
            echo "            <a href=\"";
            echo $this->env->getExtension('routing')->getPath("fos_user_security_login");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.login", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>
        ";
        }
        // line 19
        echo "    </div>

    ";
        // line 21
        if ($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "hasPreviousSession", array())) {
            // line 22
            echo "        ";
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "all", array(), "method"));
            foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
                // line 23
                echo "            ";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($context["messages"]);
                foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                    // line 24
                    echo "                <div class=\"flash-";
                    echo twig_escape_filter($this->env, $context["type"], "html", null, true);
                    echo "\">
                    ";
                    // line 25
                    echo twig_escape_filter($this->env, $context["message"], "html", null, true);
                    echo "
                </div>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 28
                echo "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 29
            echo "    ";
        }
        // line 30
        echo "
    <div>
        ";
        // line 32
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 34
        echo "    </div>
        
    </div>
";
        
        $__internal_f2d746e99ad657ea9b3595a34515d0f8ceb1cf19995e2b553790fa762e59fb57->leave($__internal_f2d746e99ad657ea9b3595a34515d0f8ceb1cf19995e2b553790fa762e59fb57_prof);

    }

    // line 32
    public function block_fos_user_content($context, array $blocks = array())
    {
        $__internal_fcf4dbf2c9b62faf77eb75d9ca8303f9fcb14035ce50c3cee82bd2fc2d89f56d = $this->env->getExtension("native_profiler");
        $__internal_fcf4dbf2c9b62faf77eb75d9ca8303f9fcb14035ce50c3cee82bd2fc2d89f56d->enter($__internal_fcf4dbf2c9b62faf77eb75d9ca8303f9fcb14035ce50c3cee82bd2fc2d89f56d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "fos_user_content"));

        // line 33
        echo "        ";
        
        $__internal_fcf4dbf2c9b62faf77eb75d9ca8303f9fcb14035ce50c3cee82bd2fc2d89f56d->leave($__internal_fcf4dbf2c9b62faf77eb75d9ca8303f9fcb14035ce50c3cee82bd2fc2d89f56d_prof);

    }

    // line 39
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_8db59a4e4c187f1b3e14a52cc4a6f5dc3f531c79a5e2dcb5cd859d3144c293cc = $this->env->getExtension("native_profiler");
        $__internal_8db59a4e4c187f1b3e14a52cc4a6f5dc3f531c79a5e2dcb5cd859d3144c293cc->enter($__internal_8db59a4e4c187f1b3e14a52cc4a6f5dc3f531c79a5e2dcb5cd859d3144c293cc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 40
        echo "    ";
        $this->displayParentBlock("javascripts", $context, $blocks);
        echo "
";
        
        $__internal_8db59a4e4c187f1b3e14a52cc4a6f5dc3f531c79a5e2dcb5cd859d3144c293cc->leave($__internal_8db59a4e4c187f1b3e14a52cc4a6f5dc3f531c79a5e2dcb5cd859d3144c293cc_prof);

    }

    public function getTemplateName()
    {
        return "FOSUserBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  165 => 40,  159 => 39,  152 => 33,  146 => 32,  136 => 34,  134 => 32,  130 => 30,  127 => 29,  121 => 28,  112 => 25,  107 => 24,  102 => 23,  97 => 22,  95 => 21,  91 => 19,  83 => 17,  77 => 14,  73 => 13,  68 => 12,  66 => 11,  59 => 8,  53 => 7,  43 => 4,  37 => 3,  11 => 1,);
    }
}
/* {% extends 'base.html.twig' %}*/
/* */
/* {% block stylesheets %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {{ parent() }}*/
/*     <div class="container">*/
/*     <div>*/
/*         {% if is_granted("IS_AUTHENTICATED_REMEMBERED") %}*/
/*             {{ 'layout.logged_in_as'|trans({'%username%': app.user.username}, 'FOSUserBundle') }} |*/
/*             <a href="{{ path('fos_user_security_logout') }}">*/
/*                 {{ 'layout.logout'|trans({}, 'FOSUserBundle') }}*/
/*             </a>*/
/*         {% else %}*/
/*             <a href="{{ path('fos_user_security_login') }}">{{ 'layout.login'|trans({}, 'FOSUserBundle') }}</a>*/
/*         {% endif %}*/
/*     </div>*/
/* */
/*     {% if app.request.hasPreviousSession %}*/
/*         {% for type, messages in app.session.flashbag.all() %}*/
/*             {% for message in messages %}*/
/*                 <div class="flash-{{ type }}">*/
/*                     {{ message }}*/
/*                 </div>*/
/*             {% endfor %}*/
/*         {% endfor %}*/
/*     {% endif %}*/
/* */
/*     <div>*/
/*         {% block fos_user_content %}*/
/*         {% endblock fos_user_content %}*/
/*     </div>*/
/*         */
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block javascripts %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
