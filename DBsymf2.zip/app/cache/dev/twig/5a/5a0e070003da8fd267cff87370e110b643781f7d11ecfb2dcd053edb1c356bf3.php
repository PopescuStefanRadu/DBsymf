<?php

/* base.html.twig */
class __TwigTemplate_dad0b20627e79a953a14141df53286753ee08c1f873487b99edc0aa09d0fc51e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b782af3c9badf47be7ec29fd10034655e3e91cc9e504ed7b7f81b0ef5be8bd64 = $this->env->getExtension("native_profiler");
        $__internal_b782af3c9badf47be7ec29fd10034655e3e91cc9e504ed7b7f81b0ef5be8bd64->enter($__internal_b782af3c9badf47be7ec29fd10034655e3e91cc9e504ed7b7f81b0ef5be8bd64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <meta name=\"description\" content=\"Despre carte si alte arte\">
        <meta name=\"author\" content=\"Iulia Albota\">
        ";
        // line 8
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 12
        echo "
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/img/mysql.png"), "html", null, true);
        echo "\" />

    </head>
    <body>
        ";
        // line 17
        $this->displayBlock('body', $context, $blocks);
        // line 22
        echo "

        ";
        // line 24
        $this->displayBlock('javascripts', $context, $blocks);
        // line 28
        echo "    </body>
</html>
";
        
        $__internal_b782af3c9badf47be7ec29fd10034655e3e91cc9e504ed7b7f81b0ef5be8bd64->leave($__internal_b782af3c9badf47be7ec29fd10034655e3e91cc9e504ed7b7f81b0ef5be8bd64_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_1763ed9b70594b635a4a13248f924e227fc29bcfa3639091afdfcf9c1018c533 = $this->env->getExtension("native_profiler");
        $__internal_1763ed9b70594b635a4a13248f924e227fc29bcfa3639091afdfcf9c1018c533->enter($__internal_1763ed9b70594b635a4a13248f924e227fc29bcfa3639091afdfcf9c1018c533_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "DBProject";
        
        $__internal_1763ed9b70594b635a4a13248f924e227fc29bcfa3639091afdfcf9c1018c533->leave($__internal_1763ed9b70594b635a4a13248f924e227fc29bcfa3639091afdfcf9c1018c533_prof);

    }

    // line 8
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_00d2f39aa3f8e08341f48ea93ca2b694d962ef797a75f826ec1cd98d58538709 = $this->env->getExtension("native_profiler");
        $__internal_00d2f39aa3f8e08341f48ea93ca2b694d962ef797a75f826ec1cd98d58538709->enter($__internal_00d2f39aa3f8e08341f48ea93ca2b694d962ef797a75f826ec1cd98d58538709_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 9
        echo "            <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/bootstrap_1.css"), "html", null, true);
        echo "\"/>
            <link rel=\"stylesheet\" type=\"text/css\" href=\"";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/public/css/base.css"), "html", null, true);
        echo "\"/>
        ";
        
        $__internal_00d2f39aa3f8e08341f48ea93ca2b694d962ef797a75f826ec1cd98d58538709->leave($__internal_00d2f39aa3f8e08341f48ea93ca2b694d962ef797a75f826ec1cd98d58538709_prof);

    }

    // line 17
    public function block_body($context, array $blocks = array())
    {
        $__internal_8d28046045c4d86a98be44930ef12161c1388637b4478740d9b026cc3bfccf8a = $this->env->getExtension("native_profiler");
        $__internal_8d28046045c4d86a98be44930ef12161c1388637b4478740d9b026cc3bfccf8a->enter($__internal_8d28046045c4d86a98be44930ef12161c1388637b4478740d9b026cc3bfccf8a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 18
        echo "            <div class=\"container-fluid\">
            </div>
            ";
        // line 20
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("AppBundle:Default:navigation"));
        echo "
        ";
        
        $__internal_8d28046045c4d86a98be44930ef12161c1388637b4478740d9b026cc3bfccf8a->leave($__internal_8d28046045c4d86a98be44930ef12161c1388637b4478740d9b026cc3bfccf8a_prof);

    }

    // line 24
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_79ea2cda718ecf2124e33e3dd4ff18886fa34c349b7c47ce1c85de5bb14d15a6 = $this->env->getExtension("native_profiler");
        $__internal_79ea2cda718ecf2124e33e3dd4ff18886fa34c349b7c47ce1c85de5bb14d15a6->enter($__internal_79ea2cda718ecf2124e33e3dd4ff18886fa34c349b7c47ce1c85de5bb14d15a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 25
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/jquery/dist/jquery.js"), "html", null, true);
        echo "\"></script>
            <script src=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/vendor/bootstrap/dist/js/bootstrap.js"), "html", null, true);
        echo "\"></script>
        ";
        
        $__internal_79ea2cda718ecf2124e33e3dd4ff18886fa34c349b7c47ce1c85de5bb14d15a6->leave($__internal_79ea2cda718ecf2124e33e3dd4ff18886fa34c349b7c47ce1c85de5bb14d15a6_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 26,  124 => 25,  118 => 24,  109 => 20,  105 => 18,  99 => 17,  90 => 10,  85 => 9,  79 => 8,  67 => 5,  58 => 28,  56 => 24,  52 => 22,  50 => 17,  43 => 13,  40 => 12,  38 => 8,  32 => 5,  26 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html>*/
/*     <head>*/
/*         <meta charset="UTF-8" />*/
/*         <title>{% block title %}DBProject{% endblock %}</title>*/
/*         <meta name="description" content="Despre carte si alte arte">*/
/*         <meta name="author" content="Iulia Albota">*/
/*         {% block stylesheets %}*/
/*             <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/bootstrap_1.css')}}"/>*/
/*             <link rel="stylesheet" type="text/css" href="{{asset('assets/public/css/base.css')}}"/>*/
/*         {% endblock %}*/
/* */
/*         <link rel="icon" type="image/png" href="{{ asset('assets/public/img/mysql.png') }}" />*/
/* */
/*     </head>*/
/*     <body>*/
/*         {% block body %}*/
/*             <div class="container-fluid">*/
/*             </div>*/
/*             {{ render(controller('AppBundle:Default:navigation')) }}*/
/*         {% endblock %}*/
/* */
/* */
/*         {% block javascripts %}*/
/*             <script src="{{ asset('assets/vendor/jquery/dist/jquery.js') }}"></script>*/
/*             <script src="{{ asset('assets/vendor/bootstrap/dist/js/bootstrap.js') }}"></script>*/
/*         {% endblock %}*/
/*     </body>*/
/* </html>*/
/* */
