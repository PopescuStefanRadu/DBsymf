<?php

/* partials/tagList.html.twig */
class __TwigTemplate_5ea92645690087c97b9b51cc4988a85aa75fa70a87cf35d3576ebae87e311bf7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_11421c3f8126abf7cc54899b508b50fa5e130cd8f61ef4b24f2635f2c2da78dd = $this->env->getExtension("native_profiler");
        $__internal_11421c3f8126abf7cc54899b508b50fa5e130cd8f61ef4b24f2635f2c2da78dd->enter($__internal_11421c3f8126abf7cc54899b508b50fa5e130cd8f61ef4b24f2635f2c2da78dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "partials/tagList.html.twig"));

        // line 1
        echo "<ol class=\"list-unstyled\">
    ";
        // line 2
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["tags"]) ? $context["tags"] : $this->getContext($context, "tags")));
        foreach ($context['_seq'] as $context["_key"] => $context["tag"]) {
            // line 3
            echo "        <li><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("tags_name", array("tagid" => $this->getAttribute($context["tag"], "x", array()), "tagname" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($context["tag"], "title", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["tag"], "title", array()), "html", null, true);
            echo "</a></li>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['tag'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 5
        echo "</ol>";
        
        $__internal_11421c3f8126abf7cc54899b508b50fa5e130cd8f61ef4b24f2635f2c2da78dd->leave($__internal_11421c3f8126abf7cc54899b508b50fa5e130cd8f61ef4b24f2635f2c2da78dd_prof);

    }

    public function getTemplateName()
    {
        return "partials/tagList.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 5,  29 => 3,  25 => 2,  22 => 1,);
    }
}
/* <ol class="list-unstyled">*/
/*     {% for tag in tags %}*/
/*         <li><a href="{{path('tags_name',{'tagid':tag.x,'tagname':tag.title|makeLink})}}">{{ tag.title }}</a></li>*/
/*     {% endfor %}*/
/* </ol>*/
