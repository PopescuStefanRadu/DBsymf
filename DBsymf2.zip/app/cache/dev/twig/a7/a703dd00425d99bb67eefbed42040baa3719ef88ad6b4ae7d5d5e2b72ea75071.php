<?php

/* default/navigation.html.twig */
class __TwigTemplate_800d4f87dd60e91f922273b58391c9627a5de7b4293bd03a1af4974424ca9c8d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb5f4e740b9022cc0318d3319ed5baf6832b8a508d77532cef790fed6e8f7e96 = $this->env->getExtension("native_profiler");
        $__internal_fb5f4e740b9022cc0318d3319ed5baf6832b8a508d77532cef790fed6e8f7e96->enter($__internal_fb5f4e740b9022cc0318d3319ed5baf6832b8a508d77532cef790fed6e8f7e96_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/navigation.html.twig"));

        // line 1
        echo "<nav class=\"navbar navbar-default container-fluid\">
    <div class=\"container\">
        <div class=\"navbar-header\">
            <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\"#navbar-top\" aria-expanded=\"false\">
                <span class=\"sr-only\">Toggle navigation</span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
                <span class=\"icon-bar\"></span>
            </button>
            <a class=\"navbar-brand brand-text\" href=\"";
        // line 10
        echo $this->env->getExtension('routing')->getPath("homepage");
        echo "\">Iulia Albota</a>
        </div>

        <div class=\"collapse navbar-collapse\" id=\"navbar-top\">
            <ul class=\"nav navbar-nav\">
                ";
        // line 15
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["navs"]) ? $context["navs"] : $this->getContext($context, "navs")));
        foreach ($context['_seq'] as $context["_key"] => $context["nav"]) {
            // line 16
            echo "                    ";
            if ($this->env->getExtension('app_extension')->theinstanceof($this->getAttribute($context["nav"], "navigationitem", array()), "AppBundle\\Entity\\Navigationlinks")) {
                // line 17
                echo "                        <li><a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("group_title", array("groupid" => $this->getAttribute($this->getAttribute($context["nav"], "navigationitem", array()), "x", array()), "groupt" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($this->getAttribute($context["nav"], "navigationitem", array()), "url", array())))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["nav"], "navigationitem", array()), "title", array()), "html", null, true);
                echo "</a></li>
                        ";
            } elseif ($this->env->getExtension('app_extension')->theinstanceof($this->getAttribute(            // line 18
$context["nav"], "navigationitem", array()), "AppBundle\\Entity\\Navigationdropdowns")) {
                // line 19
                echo "                        <li class=\"dropdown\"> 
                            <a href=\"#\" class=\"dropdown-toggle\" data-toggle=\"dropdown\" role=\"button\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                ";
                // line 21
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["nav"], "navigationitem", array()), "title", array()), "html", null, true);
                echo "
                                <span class=\"caret\"></span>
                            </a>
                            <ul class=\"dropdown-menu\">
                                ";
                // line 25
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($context["nav"], "navigationitem", array()), "dropdownlinklist", array()));
                foreach ($context['_seq'] as $context["_key"] => $context["dropdownlink"]) {
                    // line 26
                    echo "                                    <li><a href=\"";
                    echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("group_subgroup", array("groupid" => $this->getAttribute($this->getAttribute($context["dropdownlink"], "navigationlink", array()), "x", array()), "groupt" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($this->getAttribute($context["dropdownlink"], "navigationdropdown", array()), "url", array())), "subgroupt" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($this->getAttribute($context["dropdownlink"], "navigationlink", array()), "url", array())))), "html", null, true);
                    echo "\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["dropdownlink"], "navigationlink", array()), "title", array()), "html", null, true);
                    echo "</a></li>
                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['dropdownlink'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 28
                echo "                            </ul>
                        </li>
                    ";
            }
            // line 31
            echo "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['nav'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "            </ul>

            <ul class=\"nav navbar-nav navbar-right\">
                ";
        // line 35
        if ( !$this->env->getExtension('security')->isGranted("ROLE_USER")) {
            // line 36
            echo "                <li><a href=\"";
            echo $this->env->getExtension('routing')->getPath("fos_user_security_login");
            echo "\">Login</a></li>
                <li><a href=\"";
            // line 37
            echo $this->env->getExtension('routing')->getPath("fos_user_registration_register");
            echo "\">Register</a></li>
                ";
        } else {
            // line 39
            echo "                <li><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("user_profile_name", array("profileid" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "id", array()), "profilename" => $this->env->getExtension('make_link')->makeLink($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array())))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user", array()), "username", array()), "html", null, true);
            echo "</a></li>
                ";
        }
        // line 41
        echo "            </ul>
        </div>
    </div>
</nav>";
        
        $__internal_fb5f4e740b9022cc0318d3319ed5baf6832b8a508d77532cef790fed6e8f7e96->leave($__internal_fb5f4e740b9022cc0318d3319ed5baf6832b8a508d77532cef790fed6e8f7e96_prof);

    }

    public function getTemplateName()
    {
        return "default/navigation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  119 => 41,  111 => 39,  106 => 37,  101 => 36,  99 => 35,  94 => 32,  88 => 31,  83 => 28,  72 => 26,  68 => 25,  61 => 21,  57 => 19,  55 => 18,  48 => 17,  45 => 16,  41 => 15,  33 => 10,  22 => 1,);
    }
}
/* <nav class="navbar navbar-default container-fluid">*/
/*     <div class="container">*/
/*         <div class="navbar-header">*/
/*             <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-top" aria-expanded="false">*/
/*                 <span class="sr-only">Toggle navigation</span>*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*                 <span class="icon-bar"></span>*/
/*             </button>*/
/*             <a class="navbar-brand brand-text" href="{{path('homepage')}}">Iulia Albota</a>*/
/*         </div>*/
/* */
/*         <div class="collapse navbar-collapse" id="navbar-top">*/
/*             <ul class="nav navbar-nav">*/
/*                 {% for nav in navs %}*/
/*                     {% if nav.navigationitem is aninstanceof('AppBundle\\Entity\\Navigationlinks') %}*/
/*                         <li><a href="{{ path('group_title',{'groupid':nav.navigationitem.x,'groupt':nav.navigationitem.url|makeLink}) }}">{{nav.navigationitem.title}}</a></li>*/
/*                         {% elseif nav.navigationitem is aninstanceof('AppBundle\\Entity\\Navigationdropdowns') %}*/
/*                         <li class="dropdown"> */
/*                             <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">*/
/*                                 {{nav.navigationitem.title}}*/
/*                                 <span class="caret"></span>*/
/*                             </a>*/
/*                             <ul class="dropdown-menu">*/
/*                                 {% for dropdownlink in nav.navigationitem.dropdownlinklist %}*/
/*                                     <li><a href="{{path('group_subgroup',{'groupid':dropdownlink.navigationlink.x,'groupt':dropdownlink.navigationdropdown.url|makeLink,'subgroupt':dropdownlink.navigationlink.url|makeLink})}}">{{dropdownlink.navigationlink.title}}</a></li>*/
/*                                 {% endfor%}*/
/*                             </ul>*/
/*                         </li>*/
/*                     {% endif %}*/
/*                 {% endfor %}*/
/*             </ul>*/
/* */
/*             <ul class="nav navbar-nav navbar-right">*/
/*                 {% if not is_granted('ROLE_USER') %}*/
/*                 <li><a href="{{path('fos_user_security_login')}}">Login</a></li>*/
/*                 <li><a href="{{path('fos_user_registration_register')}}">Register</a></li>*/
/*                 {% else %}*/
/*                 <li><a href="{{path('user_profile_name',{'profileid':app.user.id,'profilename':app.user.username|makeLink})}}">{{app.user.username}}</a></li>*/
/*                 {% endif %}*/
/*             </ul>*/
/*         </div>*/
/*     </div>*/
/* </nav>*/
